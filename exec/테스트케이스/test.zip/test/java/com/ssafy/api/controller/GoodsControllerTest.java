package com.ssafy.api.controller;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
public class GoodsControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Test
    @DisplayName("Goods 데이터 가져오기 테스트") // 테스트 케이스 이름
    public void getGoodsTest() throws Exception {
        String search = "내용";
        String con = "cu";
        Long id = 1L;
        mockMvc.perform(get("/v1/goods/updateDate")) //최근 업데이트 된 상품 조회
                .andExpect(status().isOk())
                .andDo(print());

        mockMvc.perform(get("/v1/goods")) //전체 상품 조회
                .andExpect(status().isOk())
                .andDo(print());

        mockMvc.perform(get("/v1/goods/search?search="+search)) // 검색결과에 해당되는 값 조회
                .andExpect(status().isOk())
                .andDo(print());

        mockMvc.perform(get("/v1/goods/convinence?con="+con)) //해당 편의점의 상품 조회
                .andExpect(status().isOk())
                .andDo(print());

        mockMvc.perform(get("/v1/goods/hit")) //조회수
                .andExpect(status().isOk())
                .andDo(print());

        mockMvc.perform(get("/v1/goods/"+id)) //상세 상품 조회
                .andExpect(status().isOk())
                .andDo(print());
        mockMvc.perform(get("/v1/goods/conGoods?convinenceName=cu_gs&event=1_2&goods=ml")) //상세 상품 조회
                .andExpect(status().isOk())
                .andDo(print());

        mockMvc.perform(get("/v1/goods/like")) //상세 상품 조회
                .andExpect(status().isOk())
                .andDo(print());

        mockMvc.perform(get("/v1/goods/name"))
                .andExpect(status().isOk())
                .andDo(print());

    }
}
