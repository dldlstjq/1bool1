package com.ssafy.api.controller;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
public class RecipeControllerTest {
    @Autowired
    private MockMvc mockMvc;

    @Test
    @DisplayName("Recipe 데이터 가져오기 테스트") // 테스트 케이스 이름
    public void getRecipeTest() throws Exception {
        int recipeId = 1;
        String search = "요리";
        int page = 0;
        int size = 10;
        mockMvc.perform(get("/v1/recipe?page="+page+"&size="+size)) //전체 레시피 조회
                .andExpect(status().isOk())
                .andDo(print());
        mockMvc.perform(get("/v1/recipe/"+recipeId)) //상세 레시피 조회
                .andExpect(status().isOk())
                .andDo(print());
        mockMvc.perform(get("/v1/recipe/goods/"+recipeId)) //전체 레시피 조회
                .andExpect(status().isOk())
                .andDo(print());
        mockMvc.perform(get("/v1/recipe/like")) //좋아요 순 정렬
                .andExpect(status().isOk())
                .andDo(print());
        mockMvc.perform(get("/v1/recipe/like/"+recipeId)) //해당 레시피의 좋아요 갯수를 리턴함
                .andExpect(status().isOk())
                .andDo(print());
        mockMvc.perform(get("/v1/recipe/search?search="+search)) //검색 결과를 반환 함
                .andExpect(status().isOk())
                .andDo(print());

    }

}
