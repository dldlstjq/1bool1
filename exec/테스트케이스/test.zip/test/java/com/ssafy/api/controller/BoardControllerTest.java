package com.ssafy.api.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ssafy.api.service.BoardLikeService;
import com.ssafy.api.service.BoardServiceImpl;
import com.ssafy.api.service.FireBaseService;
import com.ssafy.common.auth.SsafyUserDetailService;
import com.ssafy.db.entity.Board;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import io.opencensus.common.ServerStatsFieldEnums.Size;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import java.util.List;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.mockito.Mockito.verify;
import static org.mockito.BDDMockito.given;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.*;

@SpringBootTest
@AutoConfigureMockMvc // 이 어노테이션을 통해서 MockMvc를 Builder 없이 주입 받을 수 있음
public class BoardControllerTest {
    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private MockMvc mockMvc;

    @Test
    @DisplayName("Board 데이터 가져오기 테스트") // 테스트 케이스 이름
    public void getBoardTest() throws Exception {
        Integer page = 0;
        Integer size = 10;
        String search = "내용";
        mockMvc.perform(get("/v1/board?page="+page+"&size="+size))
                .andExpect(status().isOk())
                .andDo(print());
        mockMvc.perform(get("/v1/board/search?search="+search))
                .andExpect(status().isOk())
                .andDo(print());
        mockMvc.perform(get("/v1/board/1"))
                .andExpect(status().isOk())
                .andDo(print());
        mockMvc.perform(get("/v1/board/like/1"))
                .andExpect(status().isOk())
                .andDo(print());
        mockMvc.perform(get("/v1/board/like"))
                .andExpect(status().isOk())
                .andDo(print());
    }
}
