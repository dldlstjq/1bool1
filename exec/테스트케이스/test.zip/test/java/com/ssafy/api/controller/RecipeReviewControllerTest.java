package com.ssafy.api.controller;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
public class RecipeReviewControllerTest {
    @Autowired
    private MockMvc mockMvc;

    @Test
    @DisplayName("RecipeReview 데이터 가져오기 테스트") // 테스트 케이스 이름
    public void getRecipeReviewTest() throws Exception {
        int recipeId = 1;
        mockMvc.perform(get("/v1/recipereview/"+recipeId)) //최근 업데이트 된 상품 조회
                .andExpect(status().isOk())
                .andDo(print());

    }

}
